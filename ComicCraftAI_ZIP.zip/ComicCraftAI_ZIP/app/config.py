from functools import lru_cache
from pathlib import Path
import os

from dotenv import load_dotenv
from pydantic import BaseModel


BASE_DIR = Path(__file__).resolve().parent.parent

load_dotenv(BASE_DIR / ".env")


class Settings(BaseModel):

    gemini_api_key: str = os.getenv(
        "GEMINI_API_KEY",
        ""
    )

    hf_token: str = os.getenv(
        "HF_TOKEN",
        ""
    )

    gemini_flash_model: str = os.getenv(
        "GEMINI_FLASH_MODEL",
        "models/gemini-1.5-flash"
    )

    gemini_pro_model: str = os.getenv(
        "GEMINI_PRO_MODEL",
        "models/gemini-1.5-pro"
    )

    hf_image_model: str = os.getenv(
        "HF_IMAGE_MODEL",
        "runwayml/stable-diffusion-v1-5"
    )

    allow_demo_fallback: bool = os.getenv(
        "ALLOW_DEMO_FALLBACK",
        "true"
    ).lower() in {
        "1",
        "true",
        "yes",
        "on"
    }

    templates_dir: Path = (
        BASE_DIR / "templates"
    )

    static_dir: Path = (
        BASE_DIR / "static"
    )

    panels_dir: Path = (
        BASE_DIR / "static" / "panels"
    )

    exports_dir: Path = (
        BASE_DIR / "static" / "exports"
    )


@lru_cache
def get_settings():

    settings = Settings()

    settings.panels_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    settings.exports_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    return settings