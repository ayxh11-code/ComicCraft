from pydantic import BaseModel, Field, field_validator


class PromptRequest(BaseModel):

    story_prompt: str = Field(
        ...,
        min_length=5,
        max_length=2000
    )

    character_name: str = Field(
        ...,
        min_length=1,
        max_length=80
    )

    setting: str = Field(
        ...,
        min_length=1,
        max_length=120
    )

    tone: str = Field(
        ...,
        min_length=1,
        max_length=40
    )

    art_style: str = Field(
        ...,
        min_length=1,
        max_length=80
    )

    @field_validator("*")
    @classmethod
    def strip_values(cls, value):
        return value.strip()


class ImageTestRequest(BaseModel):

    prompt: str = Field(
        ...,
        min_length=5,
        max_length=2000
    )


class Panel(BaseModel):

    panel_number: int

    title: str

    scene_description: str

    image_prompt: str

    caption: str = ""

    narration: str = ""

    dialogue: str = ""

    image_path: str = ""