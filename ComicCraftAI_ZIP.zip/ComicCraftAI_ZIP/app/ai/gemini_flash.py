import json
import re

from app.config import get_settings


def parse_json(text):

    text = text.strip()


    if text.startswith("```"):

        text = re.sub(
            r"^```(?:json)?\s*",
            "",
            text
        )

        text = re.sub(
            r"\s*```$",
            "",
            text
        )


    try:

        return json.loads(text)

    except json.JSONDecodeError:

        start = text.find("[")

        end = text.rfind("]")


        if start >= 0 and end > start:

            return json.loads(
                text[start:end + 1]
            )

        raise


def demo_outline(
    story_prompt,
    character_name,
    setting,
    tone,
    art_style
):

    titles = [
        "The Beginning",
        "A Strange Discovery",
        "The Challenge",
        "The Turning Point",
        "A New Chapter"
    ]


    descriptions = [

        (
            f"{character_name} arrives in {setting}, "
            "ready for an unexpected adventure."
        ),

        (
            f"{character_name} discovers a "
            "mysterious clue connected to the adventure."
        ),

        (
            f"{character_name} faces a difficult "
            "challenge and must make a brave choice."
        ),

        (
            f"{character_name} finds a clever way "
            "forward and changes the situation."
        ),

        (
            f"{character_name} reaches a satisfying "
            "ending with a hint of another adventure."
        )
    ]


    panels = []


    for number in range(1, 6):

        panels.append({

            "panel_number": number,

            "title": titles[number - 1],

            "scene_description":
                descriptions[number - 1],

            "image_prompt":
                (
                    f"{character_name} in {setting}, "
                    f"{art_style} comic illustration, "
                    f"{tone} mood, consistent character "
                    f"design, panel {number}, "
                    "cinematic composition"
                )
        })


    return panels


def generate_outline(
    story_prompt,
    character_name,
    setting,
    tone,
    art_style
):

    settings = get_settings()


    if not settings.gemini_api_key:

        if settings.allow_demo_fallback:

            return demo_outline(
                story_prompt,
                character_name,
                setting,
                tone,
                art_style
            )

        raise RuntimeError(
            "GEMINI_API_KEY is not configured."
        )


    try:

        from google import genai
        from google.genai import types


        client = genai.Client(
            api_key=settings.gemini_api_key
        )


        prompt = f"""
Create a structured five-panel comic outline.

Story idea:
{story_prompt}

Main character:
{character_name}

Setting:
{setting}

Tone:
{tone}

Art style:
{art_style}

Return ONLY valid JSON.

Return an array containing exactly five objects.

Every object must contain:

panel_number
title
scene_description
image_prompt

Panel numbers must be 1 through 5.

Keep the main character visually consistent
across all panels.

Make the story flow naturally from panel 1
to panel 5.

Do not include markdown.
"""


        response = client.models.generate_content(

            model=settings.gemini_flash_model,

            contents=prompt,

            config=types.GenerateContentConfig(

                temperature=0.8,

                response_mime_type="application/json"
            )
        )


        data = parse_json(
            response.text
        )


        if not isinstance(data, list):

            raise ValueError(
                "Gemini did not return a list."
            )


        if len(data) != 5:

            raise ValueError(
                "Gemini did not return exactly five panels."
            )


        return data


    except Exception:

        if settings.allow_demo_fallback:

            return demo_outline(
                story_prompt,
                character_name,
                setting,
                tone,
                art_style
            )

        raise