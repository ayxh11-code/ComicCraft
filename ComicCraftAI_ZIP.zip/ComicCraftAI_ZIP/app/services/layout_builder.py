from app.models import Panel


def build_comic_layout(
    outline,
    story,
    image_paths
):

    story_by_panel = {
        item["panel_number"]: item
        for item in story
    }

    panels = []

    for index, item in enumerate(outline):

        panel_number = item["panel_number"]

        story_item = story_by_panel.get(
            panel_number,
            {}
        )

        image_path = ""

        if index < len(image_paths):

            image_path = image_paths[index]

        panel = Panel(

            panel_number=panel_number,

            title=item.get(
                "title",
                f"Panel {panel_number}"
            ),

            scene_description=item.get(
                "scene_description",
                ""
            ),

            image_prompt=item.get(
                "image_prompt",
                ""
            ),

            caption=story_item.get(
                "caption",
                ""
            ),

            narration=story_item.get(
                "narration",
                ""
            ),

            dialogue=story_item.get(
                "dialogue",
                ""
            ),

            image_path=image_path
        )

        panels.append(panel)

    return panels