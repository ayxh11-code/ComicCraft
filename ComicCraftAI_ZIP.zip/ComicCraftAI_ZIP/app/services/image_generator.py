from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import textwrap

from app.config import get_settings


def create_demo_image(
    prompt,
    output_path,
    panel_number,
    character_image_path=None
):

    width = 1024
    height = 768

    image = Image.new(
        "RGB",
        (width, height),
        "white"
    )

    draw = ImageDraw.Draw(image)

    try:
        title_font = ImageFont.truetype(
            "arial.ttf",
            42
        )

        text_font = ImageFont.truetype(
            "arial.ttf",
            26
        )

    except:

        title_font = ImageFont.load_default()
        text_font = ImageFont.load_default()

    # Border
    draw.rectangle(
        (20, 20, width - 20, height - 20),
        outline="black",
        width=5
    )

    # Title
    draw.text(
        (50, 50),
        f"ComicCraft - Panel {panel_number}",
        fill="black",
        font=title_font
    )

    # Insert character image
    if character_image_path:

        character_image = Image.open(
            character_image_path
        ).convert("RGB")

        # Resize while keeping the character visible
        character_image.thumbnail(
            (450, 450)
        )

        image.paste(
            character_image,
            (500, 150)
        )

    # Prompt text
    text = textwrap.fill(
        prompt,
        width=45
    )

    draw.text(
        (60, 180),
        text,
        fill="black",
        font=text_font
    )

    draw.text(
        (60, 650),
        "AI Comic Illustration",
        fill="black",
        font=text_font
    )

    image.save(
        output_path
    )


def generate_image(
    prompt,
    panel_number,
    character_image_path=None
):

    settings = get_settings()

    filename = (
        f"panel_{panel_number}.png"
    )

    output_path = (
        settings.panels_dir / filename
    )

    create_demo_image(
        prompt,
        output_path,
        panel_number,
        character_image_path
    )

    return (
        f"/static/panels/{filename}"
    )