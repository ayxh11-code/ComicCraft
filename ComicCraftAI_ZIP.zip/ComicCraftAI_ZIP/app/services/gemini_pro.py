import json
import re

from app.config import get_settings


def parse_json(text):

    text = text.strip()

    if text.startswith("```"):

        text = re.sub(
            r"^```(?:json)?\s*",
            "",
            text
        )

        text = re.sub(
            r"\s*```$",
            "",
            text
        )

    try:

        return json.loads(text)

    except json.JSONDecodeError:

        start = text.find("[")

        end = text.rfind("]")

        if start >= 0 and end > start:

            return json.loads(
                text[start:end + 1]
            )

        raise


def demo_story(
    outline,
    character_name
):

    result = []

    for panel in outline:

        number = panel["panel_number"]

        if number < 5:

            dialogue = (
                f'{character_name}: '
                '"I have to keep going!"'
            )

        else:

            dialogue = (
                f'{character_name}: '
                '"Every adventure begins '
                'with one brave step."'
            )

        result.append({

            "panel_number": number,

            "caption":
                f"Panel {number} - "
                "The adventure continues.",

            "narration":
                panel["scene_description"],

            "dialogue":
                dialogue
        })

    return result


def generate_story(
    outline,
    character_name,
    tone
):

    settings = get_settings()

    if not settings.gemini_api_key:

        if settings.allow_demo_fallback:

            return demo_story(
                outline,
                character_name
            )

        raise RuntimeError(
            "GEMINI_API_KEY is not configured."
        )

    try:

        from google import genai
        from google.genai import types

        client = genai.Client(
            api_key=settings.gemini_api_key
        )

        prompt = f"""
Expand the following five-panel comic outline
into a complete comic story.

Main character:
{character_name}

Tone:
{tone}

Outline:
{json.dumps(outline, ensure_ascii=False)}

Return ONLY valid JSON.

Return exactly five objects.

Each object must contain:

panel_number
caption
narration
dialogue

Keep the narration concise and engaging.

Dialogue should sound natural and fit the
character and scene.

Make sure the story progresses naturally.

Do not include markdown.
"""

        response = client.models.generate_content(

            model=settings.gemini_pro_model,

            contents=prompt,

            config=types.GenerateContentConfig(

                temperature=0.85,

                response_mime_type="application/json"
            )
        )

        data = parse_json(
            response.text
        )

        if not isinstance(data, list):

            raise ValueError(
                "Invalid story response."
            )

        if len(data) != 5:

            raise ValueError(
                "Story must contain five panels."
            )

        return data

    except Exception:

        if settings.allow_demo_fallback:

            return demo_story(
                outline,
                character_name
            )

        raise