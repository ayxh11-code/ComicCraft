from pathlib import Path

from fpdf import FPDF

from app.config import get_settings


def save_pdf(panels):

    settings = get_settings()

    output_path = (
        settings.exports_dir /
        "comiccraft_comic.pdf"
    )

    pdf = FPDF(
        orientation="P",
        unit="mm",
        format="A4"
    )

    pdf.set_auto_page_break(
        auto=True,
        margin=15
    )

    for panel in panels:

        pdf.add_page()

        pdf.set_font(
            "Arial",
            "B",
            18
        )

        pdf.cell(
            0,
            12,
            f"Panel {panel.panel_number}: "
            f"{panel.title}",
            ln=True
        )

        if panel.image_path:

            image_path = Path(
                panel.image_path
            )

            if not image_path.is_absolute():

                image_path = (
                    settings.static_dir /
                    image_path.as_posix()
                    .replace(
                        "/static/",
                        ""
                    )
                    .lstrip("/")
                )

            if image_path.exists():

                pdf.image(
                    str(image_path),
                    x=15,
                    y=35,
                    w=180
                )

        pdf.ln(8)

        pdf.set_font(
            "Arial",
            "",
            12
        )

        if panel.caption:

            pdf.multi_cell(
                0,
                7,
                f"Caption: {panel.caption}"
            )

        if panel.narration:

            pdf.multi_cell(
                0,
                7,
                f"Narration: {panel.narration}"
            )

        if panel.dialogue:

            pdf.multi_cell(
                0,
                7,
                f"Dialogue: {panel.dialogue}"
            )

    pdf.output(
        str(output_path)
    )

    return (
        f"/static/exports/"
        f"{output_path.name}"
    )


def export_comic_pdf(panels):

    return save_pdf(panels)