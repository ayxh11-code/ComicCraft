from pathlib import Path

from fastapi import APIRouter, Form, Request, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from app.config import get_settings
from app.models import ImageTestRequest, PromptRequest
from app.services.exporters import save_pdf
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout


settings = get_settings()

router = APIRouter()

templates = Jinja2Templates(
    directory=str(settings.templates_dir)
)


def create_comic(
    request_data,
    character_image_path=None
):

    outline = generate_outline(
        request_data.story_prompt,
        request_data.character_name,
        request_data.setting,
        request_data.tone,
        request_data.art_style
    )

    story = generate_story(
        outline,
        request_data.character_name,
        request_data.tone
    )

    image_paths = []

    for panel in outline:

        image_path = generate_image(
            panel["image_prompt"],
            panel["panel_number"],
            character_image_path
        )

        image_paths.append(
            image_path
        )

    panels = build_comic_layout(
        outline,
        story,
        image_paths
    )

    return panels


@router.get(
    "/",
    response_class=HTMLResponse
)
async def home(request: Request):

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request
        }
    )


@router.post(
    "/generate",
    response_class=HTMLResponse
)
async def generate_comic(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
    character_image: UploadFile | None = File(None)
):

    request_data = PromptRequest(
        story_prompt=story_prompt,
        character_name=character_name,
        setting=setting,
        tone=tone,
        art_style=art_style
    )

    character_image_path = None

    if character_image is not None:

        if character_image.filename:

            upload_dir = (
                settings.panels_dir.parent / "uploads"
            )

            upload_dir.mkdir(
                parents=True,
                exist_ok=True
            )

            safe_filename = Path(
                character_image.filename
            ).name

            character_image_path = (
                upload_dir / safe_filename
            )

            image_data = await character_image.read()

            with open(
                character_image_path,
                "wb"
            ) as f:

                f.write(image_data)

    panels = create_comic(
        request_data,
        character_image_path
    )

    pdf_path = save_pdf(
        panels
    )

    return templates.TemplateResponse(
        "comic_preview.html",
        {
            "request": request,
            "panels": panels,
            "pdf_path": pdf_path
        }
    )


@router.post(
    "/generate-comic/json"
)
async def generate_comic_json(
    request_data: PromptRequest
):

    panels = create_comic(
        request_data
    )

    return JSONResponse(
        content={
            "success": True,
            "panels": [
                panel.model_dump()
                for panel in panels
            ]
        }
    )


@router.get(
    "/export-success",
    response_class=HTMLResponse
)
async def export_success(
    request: Request
):

    return templates.TemplateResponse(
        "export_success.html",
        {
            "request": request
        }
    )


@router.post(
    "/test-image"
)
async def test_image(
    request_data: ImageTestRequest
):

    image_path = generate_image(
        request_data.prompt,
        1
    )

    return {
        "success": True,
        "image_path": image_path
    }